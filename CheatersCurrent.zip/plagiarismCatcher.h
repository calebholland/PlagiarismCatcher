//
// Created by caleb on 4/28/19.
//

#ifndef CHEATERS_PLAGIARISMCATCHER_H
#define CHEATERS_PLAGIARISMCATCHER_H

#endif //CHEATERS_PLAGIARISMCATCHER_H

#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>

using namespace std;


